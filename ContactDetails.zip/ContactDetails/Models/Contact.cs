﻿using System.Collections.Generic;
using Microsoft.Data.SqlClient;


namespace ContactDetails.Models
{
    public class Contact
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }

        // LocalDB SQL Server connection
        private static string ConnectionString =
            @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ContactsDB;Integrated Security=True";
        
        //
        // private static string ConnectionString =
    //@"Data Source=(localdb)\ProjectModels;Initial Catalog=ContactsDB;Integrated Security=True";

        public static List<Contact> GetAll(string search = "")
        {
            var list = new List<Contact>();
            using var conn = new SqlConnection(ConnectionString);
            conn.Open();

            string query = "SELECT * FROM Contacts";
            if (!string.IsNullOrEmpty(search))
                query += " WHERE Name LIKE @search OR Email LIKE @search";

            using var cmd = new SqlCommand(query, conn);
            if (!string.IsNullOrEmpty(search))
                cmd.Parameters.AddWithValue("@search", "%" + search + "%");

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new Contact
                {
                    Id = (int)reader["Id"],
                    Name = (string)reader["Name"],
                    Email = (string)reader["Email"],
                    PhoneNumber = (string)reader["PhoneNumber"]
                });
            }

            return list;
        }

        public void Add()
        {
            using var conn = new SqlConnection(ConnectionString);
            conn.Open();

            string query = "INSERT INTO Contacts (Name, Email, PhoneNumber) VALUES (@Name, @Email, @PhoneNumber)";
            using var cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Name", Name);
            cmd.Parameters.AddWithValue("@Email", Email);
            cmd.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
            cmd.ExecuteNonQuery();
        }

        public void Update()
        {
            using var conn = new SqlConnection(ConnectionString);
            conn.Open();

            string query = "UPDATE Contacts SET Name=@Name, Email=@Email, PhoneNumber=@PhoneNumber WHERE Id=@Id";
            using var cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Id", Id);
            cmd.Parameters.AddWithValue("@Name", Name);
            cmd.Parameters.AddWithValue("@Email", Email);
            cmd.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
            cmd.ExecuteNonQuery();
        }

        public static Contact GetById(int id)
        {
            using var conn = new SqlConnection(ConnectionString);
            conn.Open();

            string query = "SELECT * FROM Contacts WHERE Id=@Id";
            using var cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Id", id);

            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                return new Contact
                {
                    Id = (int)reader["Id"],
                    Name = (string)reader["Name"],
                    Email = (string)reader["Email"],
                    PhoneNumber = (string)reader["PhoneNumber"]
                };
            }

            return null;
        }

        public static void Delete(int id)
        {
            using var conn = new SqlConnection(ConnectionString);
            conn.Open();

            string query = "DELETE FROM Contacts WHERE Id=@Id";
            using var cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@Id", id);
            cmd.ExecuteNonQuery();
        }
    }
}
