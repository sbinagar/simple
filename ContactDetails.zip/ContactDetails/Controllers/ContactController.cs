﻿using Microsoft.AspNetCore.Mvc;
using ContactDetails.Models;

namespace ContactDetails.Controllers
{
    public class ContactController : Controller
    {
        public IActionResult Index(string search)
        {
            var contacts = Contact.GetAll(search);
            return View(contacts);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Contact contact)
        {
            if (!ModelState.IsValid)
                return View(contact);

            contact.Add();
            return RedirectToAction("Index");
        }

        public IActionResult Edit(int id)
        {
            var contact = Contact.GetById(id);
            if (contact == null) return NotFound();
            return View(contact);
        }

        [HttpPost]
        public IActionResult Edit(Contact contact)
        {
            if (!ModelState.IsValid)
                return View(contact);

            contact.Update();
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            var contact = Contact.GetById(id);
            if (contact == null) return NotFound();
            return View(contact);
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            Contact.Delete(id);
            return RedirectToAction("Index");
        }
    }
}
