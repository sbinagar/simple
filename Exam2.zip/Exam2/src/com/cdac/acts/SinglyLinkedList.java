package com.cdac.acts;

public class SinglyLinkedList {
	private Node head;

	public void addAtLast(int data) {
		Node newNode = new Node(data);

		if (head == null) {
			head = newNode;
			return;
		}
		Node temp = head;
		while (temp.next != null) {
			temp = temp.next;
		}
		temp.next = newNode;
	}


	// Function: Remove Duplicates
	// Time: O(n^2), Space: O(1)
	public void removeDuplicates() {
		Node current = head;

		while (current != null) {
			Node newNode = current;

			while (newNode.next != null) {
				if (newNode.next.data == current.data) {
					newNode.next = newNode.next.next; // Skip duplicate
				} else{
					newNode = newNode.next;
				}
			}

			current = current.next;
		}
	}


	// Function: Rearrange Even and Odd Elements
	// Time: O(n), Space: O(1)
	public void rearrangeEvenOdd() {
		if (head == null) {
			return;
		}
		
		Node current = head;
		Node evenHead = null;
		Node oddHead = null;
		Node evenTail = null;
		Node oddTail = null;
	

		while (current != null) {
			Node nextNode = current.next;
			current.next = null;

			// Check if current node is even
			if (current.data % 2 == 0) {
				if (evenHead == null) evenHead = current;
				if (evenTail == null) evenTail = current;
				else {
					evenTail.next = current;
					evenTail = current;
				}
			}

			// Check if current node is odd
			if (current.data % 2 != 0) {
				if (oddHead == null) oddHead = current;
				if (oddTail == null) oddTail = current;
				else {
					oddTail.next = current;
					oddTail = current;
				}
			}

			current = nextNode;
		}

		// Merge even and odd lists
		if (evenTail != null) {
			evenTail.next = oddHead;
			head = evenHead;
		} else {
			head = oddHead;
		}
	}


	// Function: Print List
	public void print() {
		Node temp = head;

		while (temp != null) {
			System.out.print(temp.data + " -> ");
			temp = temp.next;
		}

		System.out.println("null");
	}
}
