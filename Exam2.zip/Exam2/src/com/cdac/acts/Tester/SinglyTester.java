package com.cdac.acts.Tester;

import com.cdac.acts.SinglyLinkedList;

public class SinglyTester {

    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();

        list.addAtLast(7);
        list.addAtLast(12);
        list.addAtLast(5);
        list.addAtLast(7);   // duplicate
        list.addAtLast(8);
        list.addAtLast(3);
        list.addAtLast(5);   // duplicate
        list.addAtLast(14);
        list.addAtLast(9);
        list.addAtLast(12);  // duplicate

        System.out.println("Singly Linked List (Used Print() method here ):");
        list.print();

        System.out.println();
        list.removeDuplicates();
        System.out.println("Duplicates Removed:");
        list.print();

        System.out.println();
        list.rearrangeEvenOdd();
        System.out.println("After Rearranging Even and Odd:");
        list.print();
    }
}
