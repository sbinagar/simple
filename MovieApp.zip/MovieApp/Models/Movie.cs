﻿using Microsoft.Data.SqlClient;
using System.Data; // Required for CommandType
using System;
using System.Collections.Generic; // Required for List

namespace MovieApp.Models
{
    public class Movie
    {
        public int Id { get; set; }
        public string MovieName { get; set; }
        public DateTime ReleaseDate { get; set; }
        public string Language { get; set; }
        public string Genre { get; set; }
        public string TheatreName { get; set; }

        // Connection string (you might want to get this from appsettings.json in a real app)
        private static string ConnectionString =
            @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ACTSJUNE25;Integrated Security=True";

        // 1. Get All Movies (equivalent to GetAllEmployees)
        public static List<Movie> GetAllMovies()
        {
            List<Movie> lstMovies = new List<Movie>();
            using (SqlConnection cn = new SqlConnection(ConnectionString)) // Use 'using' for proper disposal
            {
                try
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT * FROM Movies", cn); // Assuming table name is 'Movies'
                    cmd.CommandType = CommandType.Text;

                    using (SqlDataReader dr = cmd.ExecuteReader()) // Use 'using' for proper disposal
                    {
                        while (dr.Read())
                        {
                            Movie movie = new Movie();
                            movie.Id = dr.GetInt32("Id");
                            movie.MovieName = dr.GetString("MovieName");
                            movie.ReleaseDate = dr.GetDateTime("ReleaseDate");
                            movie.Language = dr.GetString("Language");
                            movie.Genre = dr.GetString("Genre");
                            movie.TheatreName = dr.GetString("TheatreName");
                            lstMovies.Add(movie);
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Log the exception (e.g., using a logging framework)
                    Console.WriteLine($"Error getting all movies: {ex.Message}");
                    throw; // Re-throw the exception for the calling code to handle
                }
            } // cn.Close() is implicitly called here by 'using'
            return lstMovies;
        }

        // 2. Get Single Movie (by Id)
        public static Movie GetSingleMovie(int movieId)
        {
            Movie movie = null;
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                try
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT * FROM Movies WHERE Id = @Id", cn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@Id", movieId);

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            movie = new Movie();
                            movie.Id = dr.GetInt32("Id");
                            movie.MovieName = dr.GetString("MovieName");
                            movie.ReleaseDate = dr.GetDateTime("ReleaseDate");
                            movie.Language = dr.GetString("Language");
                            movie.Genre = dr.GetString("Genre");
                            movie.TheatreName = dr.GetString("TheatreName");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error getting single movie: {ex.Message}");
                    throw;
                }
            }
            return movie;
        }

        // 3. Insert New Movie
        public static void Insert(Movie obj)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                try
                {
                    cn.Open();
                    // NOTE: Id should ideally be an IDENTITY column in the DB, so you don't insert it manually.
                    // If your DB table's Id is IDENTITY, remove @Id from the INSERT statement and parameters.
                    SqlCommand cmd = new SqlCommand(
                        "INSERT INTO Movies (MovieName, ReleaseDate, Language, Genre, TheatreName) VALUES (@MovieName, @ReleaseDate, @Language, @Genre, @TheatreName)", cn);
                    cmd.CommandType = CommandType.Text;

                    // Assuming Id is auto-incrementing in the database. If not, you'd generate and pass it.
                    // If Id is NOT IDENTITY, you'd add: cmd.Parameters.AddWithValue("@Id", obj.Id);
                    cmd.Parameters.AddWithValue("@MovieName", obj.MovieName);
                    cmd.Parameters.AddWithValue("@ReleaseDate", obj.ReleaseDate);
                    cmd.Parameters.AddWithValue("@Language", obj.Language);
                    cmd.Parameters.AddWithValue("@Genre", obj.Genre);
                    cmd.Parameters.AddWithValue("@TheatreName", obj.TheatreName);

                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error inserting movie: {ex.Message}");
                    throw;
                }
            }
        }

        // 4. Update Existing Movie
        public static void Update(Movie obj)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                try
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand(
                        "UPDATE Movies SET MovieName=@MovieName, ReleaseDate=@ReleaseDate, Language=@Language, Genre=@Genre, TheatreName=@TheatreName WHERE Id=@Id", cn);
                    cmd.CommandType = CommandType.Text;

                    cmd.Parameters.AddWithValue("@MovieName", obj.MovieName);
                    cmd.Parameters.AddWithValue("@ReleaseDate", obj.ReleaseDate);
                    cmd.Parameters.AddWithValue("@Language", obj.Language);
                    cmd.Parameters.AddWithValue("@Genre", obj.Genre);
                    cmd.Parameters.AddWithValue("@TheatreName", obj.TheatreName);
                    cmd.Parameters.AddWithValue("@Id", obj.Id); // Crucial for update

                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error updating movie: {ex.Message}");
                    throw;
                }
            }
        }

        // 5. Delete Movie
        public static void Delete(int movieId)
        {
            using (SqlConnection cn = new SqlConnection(ConnectionString))
            {
                try
                {
                    cn.Open();
                    SqlCommand cmd = new SqlCommand("DELETE FROM Movies WHERE Id=@Id", cn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@Id", movieId);

                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error deleting movie: {ex.Message}");
                    throw;
                }
            }
        }

        // Helper class for TheatreCount view (can remain outside or inside Movie class, or separate file)
        // This is a view model, not part of the database model, but used by the controller/view.
        public class TheatreMovieCount
        {
            public string TheatreName { get; set; }
            public int MovieCount { get; set; }
        }
    }
}