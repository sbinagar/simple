﻿using Microsoft.AspNetCore.Mvc;
using MovieApp.Models; // Your Movie model namespace
using System.Collections.Generic;
using System.Linq; // Still useful for LINQ-to-Objects on the list returned from DB

namespace MovieApp.Controllers
{
    public class MoviesController : Controller
    {
        // No longer need DbContext injection:
        // private readonly MovieAppContext _context;
        // public MoviesController(MovieAppContext context) { _context = context; }

        // GET: Movies (List all movies)
        public IActionResult Index(string searchString)
        {
            List<Movie> movies = Movie.GetAllMovies(); // Call the static method

            if (!string.IsNullOrEmpty(searchString))
            {
                movies = movies.Where(s => s.MovieName.Contains(searchString, StringComparison.OrdinalIgnoreCase) ||
                                           s.Language.Contains(searchString, StringComparison.OrdinalIgnoreCase) ||
                                           s.Genre.Contains(searchString, StringComparison.OrdinalIgnoreCase) ||
                                           s.TheatreName.Contains(searchString, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            return View(movies);
        }

        // GET: Movies/Create (Show form to add a movie)
        public IActionResult Create()
        {
            return View();
        }

        // POST: Movies/Create (Handle form submission to add a movie)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("MovieName,ReleaseDate,Language,Genre,TheatreName")] Movie movie)
        {
            if (ModelState.IsValid)
            {
                Movie.Insert(movie); // Call the static Insert method
                TempData["SuccessMessage"] = "Movie added successfully!";
                return RedirectToAction(nameof(Index));
            }
            return View(movie);
        }

        // GET: Movies/Delete/5 (Show confirmation for deleting a movie)
        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Movie movie = Movie.GetSingleMovie(id.Value); // Call static GetSingleMovie
            if (movie == null)
            {
                return NotFound();
            }

            return View(movie);
        }

        // POST: Movies/Delete/5 (Handle deletion of a movie)
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            // You might want to re-fetch the movie to ensure it exists before deleting
            // Movie movieToDelete = Movie.GetSingleMovie(id);
            // if (movieToDelete != null)
            // {
            Movie.Delete(id); // Call static Delete method
            TempData["SuccessMessage"] = "Movie deleted successfully!";
            // }
            return RedirectToAction(nameof(Index));
        }

        // GET: Movies/TheatreCount (Show count of movies per theatre)
        public IActionResult TheatreCount()
        {
            List<Movie> allMovies = Movie.GetAllMovies(); // Get all movies first

            var theatreCounts = allMovies
                .GroupBy(m => m.TheatreName)
                .Select(group => new Movie.TheatreMovieCount // Use Movie.TheatreMovieCount
                {
                    TheatreName = group.Key,
                    MovieCount = group.Count()
                })
                .OrderByDescending(t => t.MovieCount)
                .ToList();

            return View(theatreCounts);
        }
    }
    // You can remove the TheatreMovieCount class from here if you put it inside Movie.cs
    // Or keep it separate as before. It's a view model, not directly part of the DB model.
    // public class TheatreMovieCount { ... } // If kept here, it's not Movie.TheatreMovieCount
}