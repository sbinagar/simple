import './App.css'
import TshirtOrderForm from './components/TshirtOrderForm'

function App() {
  return (
    <div>
      <TshirtOrderForm />
    </div>
  )
}

export default App
