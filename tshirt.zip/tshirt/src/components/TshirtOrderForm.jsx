import React, { useState } from "react";

const TshirtOrderForm = () => {
  const [formData, setFormData] = useState({
    customerName: "",
    mobileNo: "",
    color: "",
    size: "",
    quantity: "",
  });

  const [errors, setErrors] = useState({});
  const [orders, setOrders] = useState([]);

  const sizes = ["S", "M", "L", "X", "XXL"];

  const validate = () => {
    const newErrors = {};

    if (
      formData.customerName.length < 10 ||
      formData.customerName.length > 20
    ) {
      newErrors.customerName =
        "Customer name must be between 10 and 20 characters.";
    }

    if (!/^\d{10}$/.test(formData.mobileNo)) {
      newErrors.mobileNo = "Mobile number must be exactly 10 digits.";
    }

    if (!formData.color.trim()) {
      newErrors.color = "Color must not be blank.";
    }

    if (!sizes.includes(formData.size)) {
      newErrors.size = "Size must be one of S, M, L, X, XXL.";
    }

    if (!/^[1-9]$/.test(formData.quantity)) {
      newErrors.quantity = "Quantity must be a single digit number (1-9).";
    }

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    validateField(name, value);
  };

  const validateField = (name, value) => {
    let error = '';

    switch (name) {
      case 'customerName':
        if (value.length < 10 || value.length > 20) {
          error = 'Customer name must be between 10 and 20 characters.';
        }
        break;
      case 'mobileNo':
        if (!/^\d{10}$/.test(value)) {
          error = 'Mobile number must be exactly 10 digits.';
        }
        break;
      case 'color':
        if (!value.trim()) {
          error = 'Color must not be blank.';
        }
        break;
      case 'size':
        if (!sizes.includes(value)) {
          error = 'Size must be one of S, M, L, X, XXL.';
        }
        break;
      case 'quantity':
        if (!/^[1-9]$/.test(value)) {
          error = 'Quantity must be a single digit number (1-9).';
        }
        break;
      default:
        break;
    }

    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: error,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      setOrders((prevOrders) => [...prevOrders, formData]);
      alert("Order submitted successfully");
      // Reset form
      setFormData({
        customerName: "",
        mobileNo: "",
        color: "",
        size: "",
        quantity: "",
      });
      setErrors({});
    }
  };

  return (
    <>
      <form
        onSubmit={handleSubmit}
        className="container mt-4"
        style={{ maxWidth: "500px" }}
      >
        <h2 className="mb-4">T-shirt Order Form</h2>

        <div className="mb-3">
          <label htmlFor="customerName" className="form-label">
            Customer Name:
          </label>
          <input
            type="text"
            id="customerName"
            name="customerName"
            className={`form-control ${errors.customerName ? "is-invalid" : ""}`}
            value={formData.customerName}
            onChange={handleChange}
            placeholder="Enter customer name"
          />
          {errors.customerName && (
            <div className="invalid-feedback">{errors.customerName}</div>
          )}
        </div>

        <div className="mb-3">
          <label htmlFor="mobileNo" className="form-label">
            Mobile No:
          </label>
          <input
            type="text"
            id="mobileNo"
            name="mobileNo"
            className={`form-control ${errors.mobileNo ? "is-invalid" : ""}`}
            value={formData.mobileNo}
            onChange={handleChange}
            placeholder="Enter 10 digit mobile number"
            maxLength={10}
          />
          {errors.mobileNo && (
            <div className="invalid-feedback">{errors.mobileNo}</div>
          )}
        </div>

        <div className="mb-3">
          <label htmlFor="color" className="form-label">
            Color:
          </label>
          <input
            type="text"
            id="color"
            name="color"
            className={`form-control ${errors.color ? "is-invalid" : ""}`}
            value={formData.color}
            onChange={handleChange}
            placeholder="Enter color"
          />
          {errors.color && (
            <div className="invalid-feedback">{errors.color}</div>
          )}
        </div>

        <div className="mb-3">
          <label htmlFor="size" className="form-label">
            Size:
          </label>
          <select
            id="size"
            name="size"
            className={`form-select ${errors.size ? "is-invalid" : ""}`}
            value={formData.size}
            onChange={handleChange}
          >
            <option value="">Select size</option>
            {sizes.map((size) => (
              <option key={size} value={size}>
                {size}
              </option>
            ))}
          </select>
          {errors.size && <div className="invalid-feedback">{errors.size}</div>}
        </div>

        <div className="mb-3">
          <label htmlFor="quantity" className="form-label">
            Quantity:
          </label>
          <input
            type="text"
            id="quantity"
            name="quantity"
            className={`form-control ${errors.quantity ? "is-invalid" : ""}`}
            value={formData.quantity}
            onChange={handleChange}
            placeholder="Enter quantity (1-9)"
            maxLength={1}
          />
          {errors.quantity && (
            <div className="invalid-feedback">{errors.quantity}</div>
          )}
        </div>

        <button type="submit" className="btn btn-primary">
          Submit Order
        </button>
      </form>

      {orders.length > 0 && (
        <div className="container mt-5" style={{ maxWidth: "700px" }}>
          <h3>Submitted Orders</h3>
          <table className="table table-bordered table-striped mt-3">
            <thead className="table-dark">
              <tr>
                <th>Customer Name</th>
                <th>Mobile No</th>
                <th>Color</th>
                <th>Size</th>
                <th>Quantity</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order, index) => (
                <tr key={index}>
                  <td>{order.customerName}</td>
                  <td>{order.mobileNo}</td>
                  <td>{order.color}</td>
                  <td>{order.size}</td>
                  <td>{order.quantity}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
};

export default TshirtOrderForm;
