package com.cdac.acts.main;

import com.cdac.acts.model.Transaction;
import com.cdac.acts.model.TransactionType;
import com.cdac.acts.exception.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    private static final String DATA_FILE = "transactions.dat";
    private static final List<Transaction> transactions = new ArrayList<>();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        loadTransactions();  // attempt to load any existing data
        boolean running = true;
        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();
            try {
                switch (choice) {
                    case "1" : addTransaction();
                    break;
                    case "2" : removeTransaction();
                    break;
                    case "3" : displayAllTransactions();
                    break;
                    case "4" : filterBySymbol();
                    break;
                    case "5" : saveTransactions();
                    break;
                    case "6" : { saveTransactions(); running = false; }
                    default : System.out.println("Invalid choice—please try again.");
                }
            } catch (InvalidInputException | TransactionNotFoundException | FileOperationException e) {
                System.out.println("Exception Occured!!! " + e.getMessage());
            }
        }
        scanner.close();
    }

    private static void printMenu() {
        System.out.println("\n--- Stock Transaction Manager ---");
        System.out.println("1) Add New Transaction");
        System.out.println("2) Remove Transaction");
        System.out.println("3) Display All Transactions");
        System.out.println("4) Filter by Stock Symbol");
        System.out.println("5) Save Transactions to File");
        System.out.println("6) Exit");
        System.out.print("Select an option: ");
    }

    private static void addTransaction() throws InvalidInputException {
        System.out.print("Enter stock symbol: ");
        String symbol = scanner.nextLine().trim().toUpperCase();
        if (!symbol.matches("[A-Z]+")) {
            throw new InvalidInputException("Stock symbol must be letters only.");
        }

        System.out.print("Enter type (BUY/SELL): ");
        TransactionType type;
        try {
            type = TransactionType.valueOf(scanner.nextLine().trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new InvalidInputException("Type must be BUY or SELL.");
        }

        System.out.print("Enter quantity: ");
        int qty;
        try {
            qty = Integer.parseInt(scanner.nextLine().trim());
            if (qty <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            throw new InvalidInputException("Quantity must be a positive integer.");
        }

        System.out.print("Enter price per share: ");
        double price;
        try {
            price = Double.parseDouble(scanner.nextLine().trim());
            if (price <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            throw new InvalidInputException("Price must be a positive number.");
        }

        System.out.print("Enter transaction date (YYYY-MM-DD): ");
        LocalDate date;
        try {
            date = LocalDate.parse(scanner.nextLine().trim());
        } catch (DateTimeParseException e) {
            throw new InvalidInputException("Date must be in YYYY-MM-DD format.");
        }

        Transaction tx = new Transaction(symbol, type, qty, price, date);
        transactions.add(tx);
        System.out.println("✅ Added: " + tx);
    }

    private static void removeTransaction() throws InvalidInputException, TransactionNotFoundException {
        System.out.print("Enter Transaction ID to remove: ");
        int id;
        try {
            id = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            throw new InvalidInputException("ID must be an integer.");
        }
        boolean removed = transactions.removeIf(t -> t.getTransactionId() == id);
        if (!removed) throw new TransactionNotFoundException(id);
        System.out.println("✅ Transaction " + id + " removed.");
    }

    private static void displayAllTransactions() {
        System.out.println("\nAll Transactions (sorted by date):");
        transactions.stream()
                    .sorted(Comparator.comparing(Transaction::getTransactionDate))
                    .forEach(System.out::println);
    }

    private static void filterBySymbol() {
        System.out.print("Enter stock symbol to filter: ");
        String symbol = scanner.nextLine().trim().toUpperCase();
        List<Transaction> filtered = transactions.stream()
            .filter(t -> t.getStockSymbol().equals(symbol))
            .collect(Collectors.toList());
        if (filtered.isEmpty()) {
            System.out.println("No transactions found for symbol: " + symbol);
        } else {
            filtered.forEach(System.out::println);
        }
    }

    private static void saveTransactions() throws FileOperationException {
        try (ObjectOutputStream oos =
                 new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            oos.writeObject(transactions);
            System.out.println("✅ Transactions saved to " + DATA_FILE);
        } catch (IOException e) {
            throw new FileOperationException("Failed to save transactions.", e);
        }
    }

    @SuppressWarnings("unchecked")
    private static void loadTransactions() {
        File f = new File(DATA_FILE);
        if (!f.exists()) return;
        try (ObjectInputStream ois =
                 new ObjectInputStream(new FileInputStream(f))) {
            List<Transaction> loaded =
                (List<Transaction>) ois.readObject();
            transactions.addAll(loaded);
            System.out.println("ℹ️  Loaded " + loaded.size() + " transactions from file.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("⚠️  Could not load transactions: " + e.getMessage());
        }
    }
}
