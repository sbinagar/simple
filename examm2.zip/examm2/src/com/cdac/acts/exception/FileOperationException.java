package com.cdac.acts.exception;

public class FileOperationException extends Exception {
	private static final long serialVersionUID = -3274050721384289859L;

	public FileOperationException(String message, Throwable cause) {
        super(message, cause);
    }
}
