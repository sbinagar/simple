package com.cdac.acts.exception;

public class TransactionNotFoundException extends Exception {

	private static final long serialVersionUID = 101883194092690024L;

	public TransactionNotFoundException(int id) {
        super("No transaction found with ID " + id);
    }
}
