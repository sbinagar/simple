package com.cdac.acts.exception;

public class InvalidInputException extends Exception {

	private static final long serialVersionUID = 1805209926794667643L;

	public InvalidInputException(String message) {
        super(message);
    }
}
