package com.cdac.acts.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.concurrent.atomic.AtomicInteger;

public class Transaction implements Serializable {
    
	private static final long serialVersionUID = -251222422566009493L;

	private static final AtomicInteger ID_COUNTER = new AtomicInteger(0);

    private final int transactionId;
    private final String stockSymbol;
    private final TransactionType type;
    private final int quantity;
    private final double pricePerShare;
    private final LocalDate transactionDate;

    public Transaction(String stockSymbol,
                       TransactionType type,
                       int quantity,
                       double pricePerShare,
                       LocalDate transactionDate) {
        this.transactionId    = ID_COUNTER.incrementAndGet();
        this.stockSymbol      = stockSymbol;
        this.type             = type;
        this.quantity         = quantity;
        this.pricePerShare    = pricePerShare;
        this.transactionDate  = transactionDate;
    }

    public int getTransactionId() {
        return transactionId;
    }

    public String getStockSymbol() {
        return stockSymbol;
    }

    public TransactionType getType() {
        return type;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getPricePerShare() {
        return pricePerShare;
    }

    public LocalDate getTransactionDate() {
        return transactionDate;
    }

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", stockSymbol=" + stockSymbol + ", type=" + type
				+ ", quantity=" + quantity + ", pricePerShare=" + pricePerShare + ", transactionDate=" + transactionDate
				+ "]";
	}
    }
