package com.cdac.acts.model;

public enum TransactionType {
    BUY,
    SELL
}
