package com.cdac.acts.Tester;

import com.cdac.acts.Implementation.BTree;

public class TreeTester {

	public static void Traversal() {
		BTree binary = new BTree();

		binary.BuildTree();

		binary.InOrder();

		System.out.println();

		binary.PreOrder();

		System.out.println();

		binary.PostOrder();

	}

	public static void main(String[] args) {
		Traversal();

	}

}
