package com.cdac.acts.Implementation;

public class Node {
	
	public int data;
	public Node left;
	public Node right;
	
	
	public Node() {
		left = null;
		right = null;
	}

	public Node(int data) {
		this.data = data;
		this.left = null;
		this.right = null;
	}
	
}
