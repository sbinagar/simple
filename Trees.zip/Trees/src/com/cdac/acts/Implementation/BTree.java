package com.cdac.acts.Implementation;

public class BTree {

	public Node root;

	public BTree() {
		root = null;
	}

	public void BuildTree() {

		Node n1 = new Node(1);
		Node n2 = new Node(2);
		Node n3 = new Node(3);
		Node n4 = new Node(4);
		Node n5 = new Node(5);
		Node n6 = new Node(6);
		Node n7 = new Node(7);
		Node n8 = new Node(8);
		Node n9 = new Node(9);
		Node n10 = new Node(1);		//Duplicate Values for matching values 
		Node n11 = new Node(1);		//Duplicate Values for matching values 


		root = n1;

		n1.left = n2;
		n1.right = n3;
		n2.left = n4;
		n2.right = n5;
		n3.right = n6;
		n4.left = n7;
		n5.left = n8;
		n3.left = n9;
		n6.left = n10;
		n6.right = n11;

	}
	public void PrintCount() {
		System.out.println();
		System.out.println("Leaf Nodes: "+CountLeafNodes(root));
		System.out.println("Total Number of Nodes: "+CountNodes(root));
		System.out.println("Nodes With Values: "+CountNodesWithValue(root, 1));

	}

	public void PreOrder() {
		System.out.println("Pre-Order Traversal: ");
		PreOrder(root);
		PrintCount();
	}

	public void PostOrder() {
		System.out.println("Post-Order Traversal: ");
		PostOrder(root);
		PrintCount();
	}

	public void InOrder() {
		System.out.println("In-Order Traversal: ");
		InOrder(root);
		PrintCount();

	}

	public int CountNodes() {
		return CountNodes(root);
	}

	public int CountLeafNodes() {
		return CountLeafNodes(root);
	}

	public int CountNodesWithValue(int value) {
		return CountNodesWithValue(root, value);
	}


	private void InOrder(Node root) {

		if (root == null) {
			return;
		}
		
		if(root.left != null) {
			InOrder(root.left);
		}
		
		System.out.print(root.data + " ");
		
		if(root.right != null) {
			InOrder(root.right);	
		}

	}

	private void PreOrder(Node root) {

		if(root == null) {
			return;
		}
		
		System.out.print(root.data+" ");
		
		if(root.left != null) {
			PreOrder(root.left);
		}
		
		if(root.right != null) {
			PreOrder(root.right);
		}
	}

	private void PostOrder(Node root) {

		if(root == null) {
			return;
		}
		
		if(root.left != null) {
			PostOrder(root.left);
		}
		
		if(root.right != null) {
			PostOrder(root.right);
		}
		
		System.out.print(root.data + " ");

	}

	private int CountNodes(Node node) {
		if (node == null) {
			return 0;
		}
		return 1 + CountNodes(node.left) + CountNodes(node.right);
	}

	private int CountLeafNodes(Node node) {
		if (node == null) {
			return 0;
		}
		if (node.left == null && node.right == null) {
			return 1;
		}
		return CountLeafNodes(node.left) + CountLeafNodes(node.right);
	}

	private int CountNodesWithValue(Node node, int value) {
		if (node == null) {
			return 0;
		}
		int count = 0;
		if (node.data == value) {
			count++;
		}
		count += CountNodesWithValue(node.left, value);
		count += CountNodesWithValue(node.right, value);
		return count;
		
	}
}
