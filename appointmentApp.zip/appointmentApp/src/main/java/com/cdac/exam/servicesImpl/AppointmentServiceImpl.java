package com.cdac.exam.servicesImpl;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.cdac.exam.Entity.Appointment;
import com.cdac.exam.exception.CustomExceptionHandlers;
import com.cdac.exam.repository.AppointmentRepository;
import com.cdac.exam.services.AppointmentServices;

@Service
public class AppointmentServiceImpl implements AppointmentServices{

    @Autowired
	private AppointmentRepository repository;

	AppointmentServiceImpl(CustomExceptionHandlers customExceptionHandlers) {
    }

	@Override
	public Appointment create(Appointment appointment) {
		if (repository.existsByDoctorAndDateAndTime(appointment.getDoctor(), appointment.getDate(),
				appointment.getTime())) {
			throw new ResponseStatusException(HttpStatus.CONFLICT, "Doctor already has an appointment at this time.");
		}
		return repository.save(appointment);
	}
	
	@Override
	public List<Appointment> getUpcoming(Long userId) {
		LocalDate today = LocalDate.now();
		return repository.findByUserIdAndDateAfterOrDateEqualsOrderByDateAscTimeAsc(userId, today, today);
	}
	
	@Override
	public void cancel(Long id) {
		if (!repository.existsById(id)) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Appointment not found.");
		}
		repository.deleteById(id);
	}
}
