package com.cdac.exam.services;

import java.util.List;

import com.cdac.exam.Entity.Appointment;

public interface AppointmentServices {
	public Appointment create(Appointment appointment);
	public List<Appointment> getUpcoming(Long userId);
	public void cancel(Long id);
}
