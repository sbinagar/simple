package com.cdac.exam.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.exam.Entity.Appointment;
import com.cdac.exam.servicesImpl.AppointmentServiceImpl;

@RestController
@RequestMapping("/appointments")
public class AppointmentController {

	@Autowired
	private AppointmentServiceImpl service;

	@PostMapping
	public ResponseEntity<Appointment> createAppointment(@RequestBody Appointment appointment) {
		Appointment created = service.create(appointment);
		return ResponseEntity.status(HttpStatus.CREATED).body(created);
	}

	@GetMapping("/{userId}/upcoming")
	public ResponseEntity<List<Appointment>> getUpcoming(@PathVariable Long userId) {
		return ResponseEntity.ok(service.getUpcoming(userId));
	}

	@DeleteMapping("/{appointmentId}")
	public ResponseEntity<String> cancelAppointment(@PathVariable Long appointmentId) {
		service.cancel(appointmentId);
		return ResponseEntity.ok("Appointment cancelled successfully.");
	}
}
