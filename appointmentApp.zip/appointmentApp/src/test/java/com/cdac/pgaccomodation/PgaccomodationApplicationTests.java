package com.cdac.pgaccomodation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PgaccomodationApplicationTests {

	@Test
	void contextLoads() {
	}

}
