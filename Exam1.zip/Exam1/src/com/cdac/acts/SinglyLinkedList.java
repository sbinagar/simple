package com.cdac.acts;

public class SinglyLinkedList {
    private Node head;

    // Adds a new node with the given data at the end
    public void addAtLast(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            return;
        }

        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }
        temp.next = newNode;
    }

    // Removes duplicate elements using O(n^2) approach
    public void removeDuplicate() {
        Node current = head;

        while (current != null) {
            Node runner = current;
            while (runner.next != null) {
                if (runner.next.data == current.data) {
                    runner.next = runner.next.next; // skip duplicate
                } else {
                    runner = runner.next;
                }
            }
            current = current.next;
        }
    }

    // Rearranges the list to put even elements first, maintaining order
    public void rearrangeEvenOdd() {
        Node evenStart = null;
        Node evenEnd = null;
        Node oddStart = null;
        Node oddEnd = null;
        Node current = head;

        while (current != null) {
            Node nextNode = current.next;
            current.next = null;

            if (current.data % 2 == 0) {
                if (evenStart == null) {
                    evenStart = current;
                }
                if (evenEnd == null) {
                    evenEnd = current;
                } else {
                    evenEnd.next = current;
                    evenEnd = current;
                }
            }

            if (current.data % 2 != 0) {
                if (oddStart == null) {
                    oddStart = current;
                }
                if (oddEnd == null) {
                    oddEnd = current;
                } else {
                    oddEnd.next = current;
                    oddEnd = current;
                }
            }

            current = nextNode;
        }

        if (evenStart == null) {
            head = oddStart;
            return;
        }

        if (oddStart == null) {
            head = evenStart;
            return;
        }

        evenEnd.next = oddStart;
        head = evenStart;
    }


    // Prints the list contents
    public void print() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data);
            if (temp.next != null) System.out.print(" -> ");
            temp = temp.next;
        }
        System.out.print(" -> null");
        System.out.println();
    }
}
