package com.cdac.acts.Tester;

import com.cdac.acts.SinglyLinkedList;

public class SinglyLinkedListTester {
    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();

        list.addAtLast(1);
        list.addAtLast(2);
        list.addAtLast(3);
        list.addAtLast(2);
        list.addAtLast(4);
        list.addAtLast(5);
        list.addAtLast(3);

        System.out.print("Original list: ");
        list.print();
        
        System.out.println();

        list.removeDuplicate();
        System.out.print("After removing duplicates: ");
        list.print();
        
        System.out.println();

        list.rearrangeEvenOdd();
        System.out.print("After rearranging even and odd: ");
        list.print();
    }
}
