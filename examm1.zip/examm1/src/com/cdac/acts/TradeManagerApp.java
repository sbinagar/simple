package com.cdac.acts;

import com.cdac.acts.enums.TradeType;
import com.cdac.acts.model.TradeRecord;
import com.cdac.acts.exception.*;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.stream.Collectors;

public class TradeManagerApp {
	private static final String FILE_NAME = "trades.dat";
	private static final List<TradeRecord> trades = new ArrayList<>();
	private static final Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		loadTrades();
		boolean running = true;
		while (running) {
			showMenu();
			String choice = scanner.nextLine().trim();
			try {
				switch (choice) {
				case "1" :{ 
					addNewTrade();
					break;
				}
				case "2" :{ removeTrade();
				break;}

				case "3" :{listAllTrades();
				break;
				}
				case "4" :{ filterByTicker();
				break;
				}
				case "5" :{ saveTrades();
				break;
				}
				case "6" : { 
					saveTrades(); running = false; 
				}
				default  : System.out.println("❌ Please select a valid option.");
				}
			} catch (InvalidInputException |
					TradeNotFoundException |
					FilePersistenceException e) {
				System.out.println("⚠️  " + e.getMessage());
			}
		}
		scanner.close();
	}

	private static void showMenu() {
		System.out.println("\n=== Stock Trade Manager ===");
		System.out.println("1) Add Trade");
		System.out.println("2) Remove Trade");
		System.out.println("3) Display All Trades");
		System.out.println("4) Filter by Ticker");
		System.out.println("5) Save to File");
		System.out.println("6) Exit");
		System.out.print("Select: ");
	}

	private static void addNewTrade() throws InvalidInputException {
		System.out.print("Ticker (letters only): ");
		String ticker = scanner.nextLine().trim().toUpperCase();
		if (!ticker.matches("[A-Z]+")) {
			throw new InvalidInputException("Ticker must be letters only.");
		}

		System.out.print("Type (BUY/SELL): ");
		TradeType type;
		try {
			type = TradeType.valueOf(scanner.nextLine().trim().toUpperCase());
		} catch (IllegalArgumentException e) {
			throw new InvalidInputException("Type must be BUY or SELL.");
		}

		System.out.print("Share count: ");
		int count;
		try {
			count = Integer.parseInt(scanner.nextLine().trim());
			if (count <= 0) throw new NumberFormatException();
		} catch (NumberFormatException e) {
			throw new InvalidInputException("Share count must be positive.");
		}

		System.out.print("Price per share: ");
		double price;
		try {
			price = Double.parseDouble(scanner.nextLine().trim());
			if (price <= 0) throw new NumberFormatException();
		} catch (NumberFormatException e) {
			throw new InvalidInputException("Price must be a positive number.");
		}

		System.out.print("Date (YYYY-MM-DD): ");
		LocalDate date;
		try {
			date = LocalDate.parse(scanner.nextLine().trim());
		} catch (DateTimeParseException e) {
			throw new InvalidInputException("Invalid date format.");
		}

		TradeRecord record = new TradeRecord(ticker, type, count, price, date);
		trades.add(record);
		System.out.println("✅ Added: " + record);
	}

	private static void removeTrade() throws InvalidInputException, TradeNotFoundException {
		System.out.print("Trade ID to remove: ");
		int id;
		try {
			id = Integer.parseInt(scanner.nextLine().trim());
		} catch (NumberFormatException e) {
			throw new InvalidInputException("ID must be numeric.");
		}
		boolean removed = trades.removeIf(t -> t.getTradeId() == id);
		if (!removed) throw new TradeNotFoundException(id);
		System.out.println("✅ Removed trade ID " + id);
	}

	private static void listAllTrades() {
		System.out.println("\nAll Trades (sorted by date):");
		trades.stream()
		.sorted(Comparator.comparing(TradeRecord::getDate))
		.forEach(System.out::println);
	}

	private static void filterByTicker() {
		System.out.print("Enter ticker to filter: ");
		String ticker = scanner.nextLine().trim().toUpperCase();
		List<TradeRecord> filtered = trades.stream()
				.filter(t -> t.getTicker().equals(ticker))
				.collect(Collectors.toList());
		if (filtered.isEmpty()) {
			System.out.println("❌ No trades for ticker: " + ticker);
		} else {
			filtered.forEach(System.out::println);
		}
	}

	private static void saveTrades() throws FilePersistenceException {
		try (ObjectOutputStream oos =
				new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
			oos.writeObject(trades);
			System.out.println("✅ Saved to " + FILE_NAME);
		} catch (IOException e) {
			throw new FilePersistenceException("Failed to save trades.", e);
		}
	}

	@SuppressWarnings("unchecked")
	private static void loadTrades() {
		File f = new File(FILE_NAME);
		if (!f.exists()) return;
		try (ObjectInputStream ois =
				new ObjectInputStream(new FileInputStream(f))) {
			List<TradeRecord> loaded = (List<TradeRecord>) ois.readObject();
			trades.addAll(loaded);
			System.out.println("ℹ️  Loaded " + loaded.size() + " trades.");
		} catch (IOException | ClassNotFoundException e) {
			System.out.println("⚠️  Could not load: " + e.getMessage());
		}
	}
}
