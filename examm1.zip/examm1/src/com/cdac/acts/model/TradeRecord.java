package com.cdac.acts.model;

import com.cdac.acts.enums.TradeType;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.concurrent.atomic.AtomicInteger;

public class TradeRecord implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final AtomicInteger ID_GENERATOR = new AtomicInteger(0);

    private final int tradeId;
    private final String ticker;
    private final TradeType tradeType;
    private final int shareCount;
    private final double price;
    private final LocalDate date;

    public TradeRecord(String ticker, TradeType tradeType, int shareCount, double price, LocalDate date) {
        this.tradeId    = ID_GENERATOR.incrementAndGet();
        this.ticker     = ticker;
        this.tradeType  = tradeType;
        this.shareCount = shareCount;
        this.price      = price;
        this.date       = date;
    }

    public int getTradeId() { return tradeId; }
    public String getTicker() { return ticker; }
    public TradeType getTradeType() { return tradeType; }
    public int getShareCount() { return shareCount; }
    public double getPrice() { return price; }
    public LocalDate getDate() { return date; }

	@Override
	public String toString() {
		return "TradeRecord [tradeId=" + tradeId + ", ticker=" + ticker + ", tradeType=" + tradeType + ", shareCount="
				+ shareCount + ", price=" + price + ", date=" + date + "]";
	}


}

