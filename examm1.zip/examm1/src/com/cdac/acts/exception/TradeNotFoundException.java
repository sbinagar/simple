package com.cdac.acts.exception;

public class TradeNotFoundException extends Exception {
    private static final long serialVersionUID = 1L;
    public TradeNotFoundException(int id) {
        super("No trade found with ID " + id);
    }
}
