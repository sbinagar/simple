package com.cdac.acts.exception;

public class FilePersistenceException extends Exception {
    private static final long serialVersionUID = 1L;
    public FilePersistenceException(String msg, Throwable cause) {
        super(msg, cause);
    }
}
