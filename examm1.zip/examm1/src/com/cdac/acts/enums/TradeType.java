package com.cdac.acts.enums;

public enum TradeType {
    BUY,
    SELL
}
