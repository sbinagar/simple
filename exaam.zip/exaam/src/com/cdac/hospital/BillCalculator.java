package com.cdac.hospital;
// Functional interface for billing calculation
@FunctionalInterface
interface BillCalculator {
    double calculateBill(Patient patient);
}