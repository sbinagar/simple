package com.cdac.hospital;
// Specific validation exceptions
class InvalidNameException extends PatientException {
    public InvalidNameException(String message) { super(message); }
}