package com.cdac.hospital;
class InvalidAdmissionDateException extends PatientException {
    public InvalidAdmissionDateException(String message) { super(message); }
}