package com.cdac.hospital;
class PatientNotFoundException extends Exception {
    public PatientNotFoundException(String message) { super(message); }
}