package com.cdac.hospital;
class PatientAlreadyDischargedException extends Exception {
    public PatientAlreadyDischargedException(String message) { super(message); }
}