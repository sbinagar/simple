package com.cdac.hospital;
// Base custom exception
class PatientException extends Exception {
    public PatientException(String message) { super(message); }
}