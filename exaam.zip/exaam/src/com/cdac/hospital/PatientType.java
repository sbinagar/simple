package com.cdac.hospital;
// Enum for patient types
enum PatientType {
    IN_PATIENT, OUT_PATIENT, EMERGENCY
}