package com.cdac.hospital;
class InvalidPatientTypeException extends PatientException {
    public InvalidPatientTypeException(String message) { super(message); }
}