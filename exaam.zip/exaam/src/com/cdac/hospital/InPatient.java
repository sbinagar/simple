package com.cdac.hospital;

import java.time.LocalDate;

// Subclasses
class InPatient extends Patient {
    public InPatient(String name, int age, LocalDate date, Department dept) {
        super(name, age, date, dept, PatientType.IN_PATIENT);
    }
    @Override public double billAmount(BillCalculator calculator) { return calculator.calculateBill(this); }
}

class OutPatient extends Patient {
    public OutPatient(String name, int age, LocalDate date, Department dept) {
        super(name, age, date, dept, PatientType.OUT_PATIENT);
    }
    @Override public double billAmount(BillCalculator calculator) { return calculator.calculateBill(this); }
}

class EmergencyPatient extends Patient {
    public EmergencyPatient(String name, int age, LocalDate date, Department dept) {
        super(name, age, date, dept, PatientType.EMERGENCY);
    }
    @Override public double billAmount(BillCalculator calculator) { return calculator.calculateBill(this); }
}