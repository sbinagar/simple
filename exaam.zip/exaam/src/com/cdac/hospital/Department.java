package com.cdac.hospital;
// Enum for hospital departments
enum Department {
    CARDIOLOGY, NEUROLOGY, ONCOLOGY, PEDIATRICS, ORTHOPEDICS
}