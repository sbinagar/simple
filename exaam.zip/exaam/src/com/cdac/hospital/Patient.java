package com.cdac.hospital;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.atomic.AtomicInteger;

// Abstract Patient class
abstract class Patient {
    private static final AtomicInteger idCounter = new AtomicInteger(1000);
    private final int patientId;
    private final String name;
    private final int age;
    private final LocalDate admissionDate;
    private final Department department;
    private final PatientType type;
    private boolean discharged;

    public Patient(String name, int age, LocalDate admissionDate, Department department, PatientType type) {
        this.patientId = idCounter.getAndIncrement();
        this.name = name;
        this.age = age;
        this.admissionDate = admissionDate;
        this.department = department;
        this.type = type;
        this.discharged = false;
    }

    public int getPatientId() { return patientId; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public LocalDate getAdmissionDate() { return admissionDate; }
    public Department getDepartment() { return department; }
    public PatientType getType() { return type; }
    public boolean isDischarged() { return discharged; }
    public void discharge() { this.discharged = true; }

    public long getStayDuration() {
        return ChronoUnit.DAYS.between(admissionDate, LocalDate.now());
    }

    public abstract double billAmount(BillCalculator calculator);

    @Override
    public String toString() {
        return String.format("ID: %d, Name: %s, Age: %d, Admission: %s, Dept: %s, Type: %s", 
                patientId, name, age, admissionDate, department, type);
    }
}