package com.cdac.hospital;
class InvalidAgeException extends PatientException {
    public InvalidAgeException(String message) { super(message); }
}