package com.cdac.hospital;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
// Main management system
public class HospitalManagementSystem {
    private final List<Patient> patients = new ArrayList<>();
    private final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        new HospitalManagementSystem().run();
    }

    public void run() {
        boolean exit = false;
        while (!exit) {
            System.out.println("\n1. Add Patient\n2. Discharge Patient\n3. Display All Records\n4. Filter by Department\n5. Billing Summary\n6. Exit");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1: addPatient(); break;
                case 2: dischargePatient(); break;
                case 3: displayAllRecords(); break;
                case 4: filterByDepartment(); break;
                case 5: billingSummary(); break;
                case 6: exit = true; break;
                default:
                    System.out.println("Invalid choice");
            }
        }
        System.out.println("Exiting...");
    }

    private void addPatient() {
        try {
            scanner.nextLine();
            // Name
            System.out.print("Enter Name: ");
            String name = scanner.nextLine();
            if (name.isBlank()) throw new InvalidNameException("Name cannot be empty");
            if (name.matches("\\d+")) throw new InvalidNameException("Name cannot be numeric");

            // Age
            System.out.print("Enter Age: ");
            String ageStr = scanner.nextLine();
            int age;
            try {
                age = Integer.parseInt(ageStr);
            } catch (NumberFormatException e) {
                throw new InvalidAgeException("Age must be a valid integer");
            }
            if (age <= 0) throw new InvalidAgeException("Age must be positive");

            // Admission Date
            System.out.print("Enter Admission Date (YYYY-MM-DD): ");
            String dateStr = scanner.nextLine();
            LocalDate date;
            try {
                date = LocalDate.parse(dateStr);
            } catch (DateTimeParseException e) {
                throw new InvalidAdmissionDateException("Invalid date format. Use YYYY-MM-DD");
            }
            if (date.isAfter(LocalDate.now())) throw new InvalidAdmissionDateException("Admission date cannot be in the future");

            // Department
            System.out.print("Enter Department (" + Arrays.toString(Department.values()) + "): ");
            String deptStr = scanner.nextLine().toUpperCase();
            Department dept;
            try {
                dept = Department.valueOf(deptStr);
            } catch (IllegalArgumentException e) {
                throw new InvalidDepartmentException("Invalid department. Choose from " + Arrays.toString(Department.values()));
            }

            // Patient Type
            System.out.print("Enter Patient Type (" + Arrays.toString(PatientType.values()) + "): ");
            String typeStr = scanner.nextLine().toUpperCase();
            PatientType type;
            try {
                type = PatientType.valueOf(typeStr);
            } catch (IllegalArgumentException e) {
                throw new InvalidPatientTypeException("Invalid patient type. Choose from " + Arrays.toString(PatientType.values()));
            }

            // Instantiate correct subclass
            Patient patient;
            switch (type) {
                case IN_PATIENT: patient = new InPatient(name, age, date, dept); break;
                case OUT_PATIENT: patient = new OutPatient(name, age, date, dept); break;
                case EMERGENCY: patient = new EmergencyPatient(name, age, date, dept); break;
                default: throw new InvalidPatientTypeException("Unknown patient type");
            }

            patients.add(patient);
            System.out.println("Patient added: " + patient);
        } catch (PatientException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }

    private void dischargePatient() {
        System.out.print("Enter Patient ID to discharge: ");
        int id = scanner.nextInt();
        Optional<Patient> opt = patients.stream().filter(p -> p.getPatientId() == id).findFirst();
        try {
            Patient p = opt.orElseThrow(() -> new PatientNotFoundException("No patient with ID " + id));
            if (p.isDischarged()) throw new PatientAlreadyDischargedException("Patient already discharged");
            p.discharge();
            patients.remove(p);
            System.out.println("Patient discharged: " + p.getName());
        } catch (PatientNotFoundException | PatientAlreadyDischargedException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }

    private void displayAllRecords() {
        patients.stream()
                .sorted(Comparator.comparing(Patient::getAdmissionDate))
                .forEach(System.out::println);
    }

    private void filterByDepartment() {
        scanner.nextLine();
        System.out.print("Enter Department to filter (" + Arrays.toString(Department.values()) + "): ");
        Department dept;
        try {
            dept = Department.valueOf(scanner.nextLine().toUpperCase());
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            System.out.println("Invalid department. Choose from " + Arrays.toString(Department.values()));
            return;
        }

        System.out.print("Sort by (name/age): ");
        String sortKey = scanner.nextLine().toLowerCase();

        Comparator<Patient> comparator = sortKey.equals("age")
                ? Comparator.comparing(Patient::getAge)
                : Comparator.comparing(Patient::getName);

        patients.stream()
                .filter(p -> p.getDepartment() == dept)
                .sorted(comparator)
                .forEach(System.out::println);
    }

    private void billingSummary() {
        BillCalculator inCalc = p -> p.getStayDuration() * 500;
        BillCalculator outCalc = p -> 200;
        BillCalculator emCalc = p -> 1000;

        System.out.println("Billing Summary:");
        for (Patient p : patients) {
            double bill;
            switch (p.getType()) {
                case IN_PATIENT: bill = p.billAmount(inCalc); break;
                case OUT_PATIENT: bill = p.billAmount(outCalc); break;
                case EMERGENCY: bill = p.billAmount(emCalc); break;
                default: bill = 0;
            }
            System.out.printf("%s - Bill: %.2f\n", p, bill);
        }
    }
}