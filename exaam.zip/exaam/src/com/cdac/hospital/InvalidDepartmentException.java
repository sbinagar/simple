package com.cdac.hospital;
class InvalidDepartmentException extends PatientException {
    public InvalidDepartmentException(String message) { super(message); }
}